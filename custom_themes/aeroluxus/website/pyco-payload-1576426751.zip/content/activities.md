/*
Attrs:
  Rel_content_type: activity
Bg:
  Class: ''
  Src: '[%uploads%]/kv-team.jpg'
  Style: ''
Date: ''
Description: ''
Featured_img:
  Src: ''
Parent: ''
Priority: 0
Redirect: ''
Status: 1
Tags:
- ''
Template: page-section
Terms: []
Title: 课程活动

*/





