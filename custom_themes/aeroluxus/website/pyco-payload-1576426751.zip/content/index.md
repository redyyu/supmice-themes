/*
Bg:
  Src: '[%uploads%]/kv-index.jpg'
Button:
  Link: '#contact'
  Name: 联系我们
Carousel:
- Caption: ''
  Link: ''
  Src: '[%uploads%]/kv-index.jpg'
  Subtitle: ''
  Target: ''
  Title: ''
- Caption: ''
  Link: ''
  Src: '[%uploads%]/kv-about.jpg'
  Subtitle: ''
  Target: ''
  Title: ''
- Caption: ''
  Link: ''
  Src: '[%uploads%]/kv-team.jpg'
  Subtitle: ''
  Target: ''
  Title: ''
- Caption: ''
  Link: ''
  Src: '[%uploads%]/kv-partners.jpg'
  Subtitle: ''
  Target: ''
  Title: ''
Date: '2019-11-11'
Description: ''
Featured_img:
  Src: ''
Parent: ''
Priority: 0
Redirect: ''
Status: 1
Tags:
- ''
Template: index
Terms: []
Title: Luxury training as you have never experienced it before

*/
<p>AEROLUXUS是一家专注于提供专业化、定制化高端服务提升的培训 与咨询公司。业务内容包含高端酒店服务培训、高端商务培训、个人精修 礼仪等、航空服务提升。</p><p>公司团队起始于私人飞机的运营与管理，为全球顶级高净值人士提供 个性化的私人飞行解决方案和至臻完美的飞行服务。基于私人航空领域超五星的极致服务理念，我们将其融合、转化并延 伸推广至其他高端服务行业，提供定制化的高端服务培训课程。</p>
<h4>LUXURY TRAINING AS YOU HAVE NEVER EXPERIENCED IT BEFORE</h4>
