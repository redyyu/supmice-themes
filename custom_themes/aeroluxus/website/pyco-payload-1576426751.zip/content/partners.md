/*
Bg:
  Class: ''
  Src: '[%uploads%]/kv-profile.jpg'
  Style: ''
Date: '2019-12-13'
Description: ''
Featured_img:
  Src: ''
Parent: ''
Priority: 0
Redirect: ''
Series:
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-1.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-2.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-3.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-4.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-5.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-6.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-7.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-8.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-9.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
- Caption: ''
  Link: ''
  Src: '[%uploads%]/logo-10.png'
  Subtitle: ''
  Target: ''
  Title: Partner One
Status: 1
Tags:
- ''
Template: partner
Terms: []
Title: 合作伙伴

*/







<p><span style="font-family: &quot;Open Sans&quot;, Arial, sans-serif; text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>