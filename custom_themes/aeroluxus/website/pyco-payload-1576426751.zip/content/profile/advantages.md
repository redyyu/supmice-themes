/*
Attrs:
  Hide_content: true
Bg:
  Src: '[%uploads%]/kv-advantages.jpg'
Date: '2014-01-01'
Description: ''
Featured_img:
  Src: '[%uploads%]/banner-advantages.jpg'
Parent: ''
Priority: 20
Redirect: ''
Series:
- Caption: <p>公司拥有一支超高素养国际化的师资队伍： 来自瑞士、法国、比利时、英国、美国、 新加坡、马来西亚等十多个国家的资深培 训师，中外籍教师拥有优异的专业背景以
    及丰富的高端服务行业工作经验。</p>
  Link: ''
  Src: '[%uploads%]/ico_resources.png'
  Subtitle: ''
  Target: ''
  Title: 资源优势
- Caption: <p>核心团队皆具有十余年高端客户服务经验， 深知高净值人群服务需求，力求让每一位 客户在细节中感受尊贵与专业。 这是AEROLUXUS为高净值客户提供高标
    准服务的品质保障。</p>
  Link: ''
  Src: '[%uploads%]/ico_services.png'
  Subtitle: ''
  Target: ''
  Title: 服务优势
- Caption: <p>作为高端服务行业培训专家，我们明白鲜 有两个客户是相同的。引进欧洲顶尖培训 体系的同时，我们更注重以客户需求出发， 开发针对性课程，提供全面有效的专业服
    务，助力客户强化品牌形象。</p>
  Link: ''
  Src: '[%uploads%]/ico_contents.png'
  Subtitle: 首席培训总监
  Target: ''
  Title: 内容优势
Status: 1
Tags:
- ''
Template: profile
Terms: []
Title: 我们的优势

*/



