/*
Attrs:
  Hide_content: true
Bg:
  Src: '[%uploads%]/kv-team.jpg'
Date: '2014-01-01'
Description: ''
Featured_img:
  Src: '[%uploads%]/banner-team2.jpg'
Parent: ''
Priority: 30
Redirect: ''
Series:
- Caption: "<p>法国海军出身，飞行员、空管教员三十年飞行、机场、民航、公务机公司管理经验国内首位公务机公司外籍总经理。 带领公司荣获2018年ASBAA“亚洲最佳包机公司</p>\r\
    \n<p>精通国际高端服务礼仪与标准，致力于将私人航空业的超高端服务水准拓展到高端服务业的各个领域，并在中国落地，提升客户的核心竞争力。</p>"
  Link: ''
  Src: '[%uploads%]/team_franck.jpg'
  Subtitle: 创始人兼CEO
  Target: ''
  Title: Franck DUBARRY 先生
- Caption: "<ul>\r\n<li>语言学&教育学双硕士学位</li>\r\n<li>曾在浙江大学任教多年，为三十多个国家的留学生教授语言与文化课程</li>\r\
    \n<li>具有丰富的外事接待与跨文化沟通经验</li>\r\n</ul>\r\n<p>跨界进入公务机航空领域，参与多笔公务机买卖交易，同 时负责客户飞行支持，熟悉民航法规及航空高端服务标准。</p>"
  Link: ''
  Src: '[%uploads%]/team_jenny.jpg'
  Subtitle: COO
  Target: ''
  Title: Jenny CHEN 女士
- Caption: "<ul>\r\n<li>国际高级礼仪培训师</li>\r\n<li>中国高级茶艺师</li>\r\n<li>马来西亚人力资源官方认证专业培训师</li>\r\
    \n<li>日本Colortop形象顾问学院认证专业形象顾问</li>\r\n<li>曾任欧洲公务机公司VVIP乘务员&乘务教员</li>\r\n<li>中国民航局认证的空乘教员</li>\r\
    \n</ul>\r\n<p>为多家知名酒店、航空公司提供形象与礼仪、客户管理、花艺、茶艺、西餐礼仪等专业培训</p>"
  Link: ''
  Src: '[%uploads%]/team_rachel.jpg'
  Subtitle: 首席培训总监
  Target: ''
  Title: Rachel SUA 女士
Status: 1
Tags:
- ''
Template: profile
Terms: []
Title: 团队简介

*/

