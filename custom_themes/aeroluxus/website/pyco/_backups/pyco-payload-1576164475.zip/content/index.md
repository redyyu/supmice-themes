/*
Date: '2019-12-12'
Description: asdfsdaf
Featured_img:
  Src: '[%uploads%]/default.jpg'
Parent: ''
Priority: 1
Redirect: ''
Status: 1
Tags:
- sdfsadf
Template: index
Terms: []
Title: Sample Theme

*/



