/*
Author: Devin Pan
Date: '2015-01-27'
Description: 这里写副标题
Pic:
  src: [%uploads%]/PAN.jpg
  title: PAN.jpg
Priority: 8
Status: 1
Tags: []
Template: page
Title: Contact
Type: page
Updated: 1441042179
Url: http://www.devinpan.com/contact
*/
<h3>Devin Pan Photography</h3><p>Contact Number: +86 18516262490</p><p>Primary Email: <a href="mailto:412519653@qq.com">412519653@qq.com</a></p><p>Alternative Email: <a href="minidevinpan@gmail.com">minidevinpan@gmail.com</a></p><p>Facebook: <a href="http://www.facebook.com/devinpan.photography">devinpan.photography</a></p><p>Wechat: panwenchi001</p><p>Weibo: <a href="http://www.weibo.com/speshowpwc">speshowpwc</a></p>