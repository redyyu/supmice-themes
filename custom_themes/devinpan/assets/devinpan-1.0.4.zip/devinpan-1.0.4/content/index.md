/*
Author: Devin Pan
Background:
  class: cover-bg bg-right
  color: ''
  repeat: ''
  src: [%uploads%]/home_bg.jpg
  style: ''
  thumbnail: [%uploads%]/thumbnails/home_bg.jpg
Date: '2015-01-27'
Description: ''
Priority: 10
Status: 1
Tags: []
Template: index
Title: Home
Updated: 1440954229
Url: http://localhost:5050/redy/devinpan/
*/
<p>
Phone：+8618516262490
<br>
Email:&nbsp;<a href="mailto:412519653@qq.com">412519653@qq.com</a>
<br>
Wechat: panwenchi001
<br>
Facebook: <a href="http://www.facebook.com/devinpan.photography">devinpan.photography</a>
<br>
</p>
<p>
  <img src="[%uploads%]/ppac.png" title="ppac" />
</p>