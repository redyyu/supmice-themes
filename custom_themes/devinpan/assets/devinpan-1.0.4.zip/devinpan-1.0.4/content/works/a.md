/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  src: [%uploads%]/PWC_5906_3.jpg
  title: PWC_5906_3.jpg
Location: Shanghai
Parent: ''
Priority: -1
Status: 1
Tags: []
Template: works
Title: 艺妓1
Type: works
Updated: 1448347107
Url: http://devinpan.com/works/a
*/
