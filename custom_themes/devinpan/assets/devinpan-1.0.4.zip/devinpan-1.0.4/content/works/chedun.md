/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_09102.jpg
  style: background-image:url([%uploads%]/PWC_09102.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_09102.jpg
Location: Shanghai
Parent: ''
Priority: 0
Status: 1
Tags: []
Template: works
Title: 车墩
Type: works
Updated: 1448349266
Url: http://devinpan.com/works/chedun
*/
