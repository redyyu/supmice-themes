/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_99752.jpg
  style: background-image:url([%uploads%]/PWC_99752.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_99752.jpg
Location: Shanghai
Parent: ''
Priority: 1
Status: 1
Tags: []
Template: works
Title: 邓坤2
Type: works
Updated: 1448351357
Url: http://devinpan.com/works/dengkun2
*/
