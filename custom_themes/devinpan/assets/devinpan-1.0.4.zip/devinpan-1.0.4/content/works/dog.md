/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/HJY_3143-.jpg
  style: background-image:url([%uploads%]/HJY_3143-.jpg);
  thumbnail: [%uploads%]/thumbnails/HJY_3143-.jpg
Location: Shanghai
Parent: ''
Priority: -1
Status: 1
Tags: []
Template: works
Title: dog
Type: works
Updated: 1448349440
Url: http://devinpan.com/works/dog
*/
