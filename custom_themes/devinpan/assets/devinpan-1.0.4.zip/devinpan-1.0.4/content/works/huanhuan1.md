/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/IR8A6056_2.jpg
  style: background-image:url([%uploads%]/IR8A6056_2.jpg);
  thumbnail: [%uploads%]/thumbnails/IR8A6056_2.jpg
Location: Shanghai
Parent: ''
Priority: 2
Status: 1
Tags: []
Template: works
Title: 欢欢1
Type: works
Updated: 1448351485
Url: http://devinpan.com/works/huanhuan1
*/
