/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_9715.jpg
  style: background-image:url([%uploads%]/PWC_9715.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_9715.jpg
Location: Shanghai
Parent: ''
Priority: 1
Status: 1
Tags: []
Template: works
Title: 考拉旅社
Type: works
Updated: 1448350528
Url: http://devinpan.com/works/kaolalvshe
*/
