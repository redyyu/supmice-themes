/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_0176.jpg
  style: background-image:url([%uploads%]/PWC_0176.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_0176.jpg
Location: Shanghai
Parent: ''
Priority: -1
Status: 1
Tags: []
Template: works
Title: 李佳霖
Type: works
Updated: 1448351387
Url: http://devinpan.com/works/lijialin1
*/
