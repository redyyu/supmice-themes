/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_39442.jpg
  style: background-image:url([%uploads%]/PWC_39442.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_39442.jpg
Location: Shanghai
Parent: ''
Priority: -1
Status: 1
Tags: []
Template: works
Title: 孙悦
Type: works
Updated: 1448350096
Url: http://devinpan.com/works/sunyue
*/
