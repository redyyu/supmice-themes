/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_6214_2.jpg
  style: background-image:url([%uploads%]/PWC_6214_2.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_6214_2.jpg
Location: Shanghai
Parent: ''
Priority: 2
Status: 1
Tags: []
Template: works
Title: 艺妓3
Type: works
Updated: 1448348579
Url: http://devinpan.com/works/yiji3
*/
