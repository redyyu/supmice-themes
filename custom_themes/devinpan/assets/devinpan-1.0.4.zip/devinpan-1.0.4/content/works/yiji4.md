/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_5921_2.jpg
  style: background-image:url([%uploads%]/PWC_5921_2.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_5921_2.jpg
Location: Shanghai
Parent: ''
Priority: 1
Status: 1
Tags: []
Template: works
Title: 艺妓4
Type: works
Updated: 1448348624
Url: http://devinpan.com/works/yiji4
*/
