/*
Author: Devin Pan
Date: '2015-11-24'
Description: ''
Featured_img:
  class: ''
  color: ''
  repeat: ''
  src: [%uploads%]/PWC_6140_2.jpg
  style: background-image:url([%uploads%]/PWC_6140_2.jpg);
  thumbnail: [%uploads%]/thumbnails/PWC_6140_2.jpg
Location: Shanghai
Parent: ''
Priority: -2
Status: 1
Tags: []
Template: works
Title: 艺妓5
Type: works
Updated: 1448348645
Url: http://devinpan.com/works/yiji5
*/
