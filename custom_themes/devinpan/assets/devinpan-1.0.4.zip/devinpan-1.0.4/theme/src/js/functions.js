$(document).ready(function() {
    if($(window).width()<768){
        var slider_footer = $("#slider-footer .footer")[0];
        $(slider_footer).clearQueue();
        $(slider_footer).animate({bottom:'0'},350,'easeOutCubic');
    }

//thumbnails scorller
    var items = $(".item");
    var pathList =  window.location.pathname.split('/');
    for (var i=pathList.length-1; i>=0; i--){
        if (pathList[i].length != 0){
            var selected = pathList[i];
            break;
        }
    }
    if (selected!=''){
            for (var i=0; i<(items.length); i++){
            if($(items[i]).attr("alias")==selected){
            $(items[i]).addClass("active");
        }
    }
    }
    else{
        $(items[0]).addClass("active");
    }

    if($(".item.active").length==0){
        $(items[0]).addClass("active");
    }

    $("#my-thumbs-list").mThumbnailScroller({
    	  type:"click-23",
       theme:"buttons-out",
         speed:30
    });

    $(".sidebar-menu").click(function(){
        inject_data();
        toggle_menu();
    });
    $(".close-btn").click(function(){
	     toggle_menu(true);
    });
    $(".invoke-area").click(function(e){
  		if (($(window).width())>768){
          toggle_menu(true);
  		}
  		else{
  			toggle_menu();
  		}
    });
    
  	$("#my-thumbs-list").mThumbnailScroller({
    	  type:"click-20",
   	   theme:"buttons-out"
  	});
	
  	if($("#slider-footer").length >0){
      var body_width = document.body.clientWidth;
      var slider_footer = $("#slider-footer .footer")[0];
      if(body_width > 640){
    		$("#slider-footer").hover(function(){
    			$(slider_footer).clearQueue();
    			$(slider_footer).animate({bottom:'0'},350,'easeOutCubic');
    		},function(){
    			$(slider_footer).clearQueue();
    			$(slider_footer).animate({bottom:'-80px'},350,'easeOutCubic');
		
    		});
      }else{
        $(slider_footer).css('bottom', '-80px');
      }
  	}

    var menu_opened = false;
    var menu_left_pos = 30;
    function toggle_menu(force_close){
        if(menu_opened || force_close){
            menu_left_pos = 30;
            $(".sidebar-right").hide();
        }else{
            $(".sidebar-right").show();
            menu_left_pos = 300;
        }
        menu_opened=!menu_opened;
        $('.sidebar-menu').css( "right", menu_left_pos+"px");
    }

	$('#worksCarousel').on('slide.bs.carousel', function () {
        menu_left_pos = 30;
        if(menu_opened==true){
			    menu_opened=false;
		    }
        $(".sidebar-right").hide();
        $('.sidebar-menu').css( "right", menu_left_pos+"px");
		
	});
  function inject_data(){
      $("#item-title").text("");
      $("#item-date").text("");
      $("#item-location").text("");
      $("#item-content").html("");

      $("#item-title").text($(".item.active").data("title"));
      $("#item-date").text($(".item.active").data("date"));
      $("#item-location").text($(".item.active").data("location"));
      $("#item-content").html($(".item.active").data("content"));
  }
  
  inject_data();
  
});


$(window).resize(function(){
    var slider_footer = $("#slider-footer .footer")[0];
    if($(window).width()<800){

        $(slider_footer).clearQueue();
        $(slider_footer).animate({bottom:'0'},350,'easeOutCubic');
    }
    else{
        $(slider_footer).clearQueue();
        $(slider_footer).animate({bottom:'-80px'},350,'easeOutCubic');
    }
});


    